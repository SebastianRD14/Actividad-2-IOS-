//
//  ViewController.swift
//  Actividad 2
//
//  Created by Alumno on 14/01/26.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        image.isUserInteractionEnabled = true
    }

    @IBAction func cambiarFondo(_ sender: Any) {
        view.backgroundColor = .blue
    }
    
    @IBOutlet weak var image: UIImageView!
    
    @IBAction func visibilidadImagen(_ sender: Any) {
        image.isHidden.toggle()
    }
    
    
    @IBAction func cambiarDeVuelta(_ sender: Any) {
        view.backgroundColor = .orange
    }
    
    
    @IBOutlet weak var edadLabel: UILabel!
    
    @IBAction func sliderEdad(_ sender: UISlider) {
        let edad = Int(sender.value)
        edadLabel.text = "\(edad)"
    }
    
    @IBAction func sliderImagen(_ sender: UISlider) {
        UIView.animate(withDuration: 0.3)
        {self.image.alpha = CGFloat(sender.value)}
    }
    
    @IBAction func cambiarImagen(_ sender: UITapGestureRecognizer) {
        let picker = UIImagePickerController()
        picker.sourceType = .photoLibrary
        picker.delegate = self
        present(picker, animated: true)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if let foto = info[.originalImage] as? UIImage {
            image.image = foto
        }
        dismiss(animated: true)
    }
}

