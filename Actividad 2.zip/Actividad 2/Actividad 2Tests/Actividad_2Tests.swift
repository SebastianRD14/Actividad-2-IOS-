//
//  Actividad_2Tests.swift
//  Actividad 2Tests
//
//  Created by Alumno on 14/01/26.
//

import Testing
@testable import Actividad_2

struct Actividad_2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
